package com.hackerthon.common;

public class XpathKeys {
	
	public static final String EMPLOYEE_ID = "XpathEmployeeIDKey";
	public static final String EMPLOYEE_Name = "XpathEmployeeNameKey";
	public static final String EMPLOYEE_ADDRESS = "XpathEmployeeAddressKey";
	public static final String EMPLOYEE_FACULTY_NAME = "XpathFacultyNameKey";
	public static final String EMPLOYEE_DEPARTMENT = "XpathDepartmentKey";
	public static final String EMPLOYEE_DESIGNATION = "XpathDesignationKey";

}
