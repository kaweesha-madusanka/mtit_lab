package com.hackerthon.common;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;

public class TransformUtil extends UtilC {

	private static final ArrayList<Map<String, String>> l = new ArrayList<Map<String, String>>();

	private static Map<String, String> m = null;

	public static void transformRequest() throws Exception {

		Source x = new StreamSource(new File(XmlConstants.EMPLOYEE_REQUEST));
		Source s = new StreamSource(new File(XmlConstants.EMPLOYEE_MODIFIED));
		Result o = new StreamResult(new File(XmlConstants.EMPLOYEE_RESPONSE));
		TransformerFactory.newInstance().newTransformer(s).transform(x, o);
	}

	public static ArrayList<Map<String, String>> XMLXPATHS() throws Exception {

		Document d = DocumentBuilderFactory.newInstance().newDocumentBuilder()
				.parse(XmlConstants.EMPLOYEE_RESPONSE);
		XPath x = XPathFactory.newInstance().newXPath();
		int n = Integer.parseInt((String) x.compile(XpathResources.EMPLOYEE).evaluate(d, XPathConstants.STRING));
		for (int i = 1; i <= n; i++) {
			m = new HashMap<String, String>();
			m.put(XpathKeys.EMPLOYEE_ID, (String) x.compile(XpathResources.EMPLOYEE_ID)
					.evaluate(d, XPathConstants.STRING));
			m.put(XpathKeys.EMPLOYEE_Name, (String) x.compile(XpathResources.EMPLOYEE_FULL_NAME)
					.evaluate(d, XPathConstants.STRING));
			m.put(XpathKeys.EMPLOYEE_ADDRESS,
					(String) x.compile(XpathResources.EMPLOYEE_ADDRESS).evaluate(d,
							XPathConstants.STRING));
			m.put(XpathKeys.EMPLOYEE_FACULTY_NAME, (String) x.compile(XpathResources.FACULTY_NAME)
					.evaluate(d, XPathConstants.STRING));
			m.put(XpathKeys.EMPLOYEE_DEPARTMENT, (String) x.compile(XpathResources.EMPLOYEE_DEPARTMENT)
					.evaluate(d, XPathConstants.STRING));
			m.put(XpathKeys.EMPLOYEE_DESIGNATION, (String) x.compile(XpathResources.EMPLOYEE_DESIGNATION)
					.evaluate(d, XPathConstants.STRING));
			l.add(m);
		}
		return l;
	}
}
