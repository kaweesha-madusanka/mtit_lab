package com.hackerthon.common;

public class XpathResources {
	
	public static final String EMPLOYEE = "count(//Employees/Employee)";
	public static final String EMPLOYEE_ID = "//Employees/Employee[\" + i + \"]/EmployeeID/text()";
	public static final String EMPLOYEE_FULL_NAME = "//Employees/Employee[\" + i + \"]/EmployeeFullName/text()";
	public static final String EMPLOYEE_ADDRESS = "//Employees/Employee[\" + i + \"]/EmployeeFullAddress/text()";
	public static final String FACULTY_NAME = "//Employees/Employee[\" + i + \"]/FacultyName/text()";
	public static final String EMPLOYEE_DEPARTMENT = "//Employees/Employee[\" + i + \"]/Department/text()";
	public static final String EMPLOYEE_DESIGNATION = "//Employees/Employee[\" + i + \"]/Designation/text()";

}
