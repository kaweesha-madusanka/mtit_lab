package com.hackerthon.common;

public class XmlConstants {
	
	public static final String EMPLOYEE_REQUEST = "src/com/hackerthon/config/EmployeeRequest.xml";
	public static final String EMPLOYEE_MODIFIED = "src/com/hackerthon/config/Employee-modified.xsl";
	public static final String EMPLOYEE_RESPONSE = "src/com/hackerthon/config/EmployeeResponse.xml";
	public static final String EMPLOYEE_QUERRY = "src/com/hackerthon/config/EmployeeQuery.xml";

}
