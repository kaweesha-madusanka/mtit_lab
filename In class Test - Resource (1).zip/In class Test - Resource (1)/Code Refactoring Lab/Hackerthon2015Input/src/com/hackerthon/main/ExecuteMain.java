package com.hackerthon.main;

import com.hackerthon.common.TransformUtil;
import com.hackerthon.service.getEmpService;

public class ExecuteMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		getEmpService employeeService = new getEmpService();
		try {
			TransformUtil.transformRequest();
			employeeService.getEmployeesFromXml();
			employeeService.createEmployeeTable();
			employeeService.addEmployee();
			employeeService.displayEmployee();
		} catch (Exception e) {
		}

	}

}
