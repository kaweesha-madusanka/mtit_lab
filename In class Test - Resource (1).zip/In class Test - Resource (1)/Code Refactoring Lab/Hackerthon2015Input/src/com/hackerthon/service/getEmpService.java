package com.hackerthon.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Map;

import com.hackerthon.common.TransformUtil;
import com.hackerthon.common.UtilC;
import com.hackerthon.common.UtilQ;
import com.hackerthon.common.XpathKeys;
import com.hackerthon.model.Employee;

public class getEmpService extends UtilC {

	private final ArrayList<Employee> employeeList = new ArrayList<Employee>();

	private static Connection connection;

	private static Statement statement;

	private PreparedStatement preparedStatement;

	public getEmpService() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection(p.getProperty("url"), p.getProperty("username"),
					p.getProperty("password"));
		} catch (Exception e) {
		} 
	}

	public void getEmployeesFromXml() {

		try {
			int s = TransformUtil.XMLXPATHS().size();
			for (int i = 0; i < s; i++) {
				Map<String, String> list = TransformUtil.XMLXPATHS().get(i);
				Employee employee = new Employee();
				employee.setEmployeeId(list.get(XpathKeys.EMPLOYEE_ID));
				employee.setFullName(list.get(XpathKeys.EMPLOYEE_Name));
				employee.setAddress(list.get(XpathKeys.EMPLOYEE_ADDRESS));
				employee.setFacultyName(list.get(XpathKeys.EMPLOYEE_FACULTY_NAME));
				employee.setDepartment(list.get(XpathKeys.EMPLOYEE_DEPARTMENT));
				employee.setDesignation(list.get(XpathKeys.EMPLOYEE_DESIGNATION));
				employeeList.add(employee);
				System.out.println(employee.toString() + "\n");
			}
		} catch (Exception e) {
		}
	}

	public void createEmployeeTable() {
		try {
			statement = connection.createStatement();
			statement.executeUpdate(UtilQ.Q("q2"));
			statement.executeUpdate(UtilQ.Q("q1"));
		} catch (Exception e) {
		}
	}

	public void addEmployee() {
		try {
			preparedStatement = connection.prepareStatement(UtilQ.Q("q3"));
			connection.setAutoCommit(false);
			for(int i = 0; i < employeeList.size(); i++){
				Employee employee = employeeList.get(i);
				preparedStatement.setString(1, employee.getEmployeeId());
				preparedStatement.setString(2, employee.getFullName());
				preparedStatement.setString(3, employee.getAddress());
				preparedStatement.setString(4, employee.getFacultyName());
				preparedStatement.setString(5, employee.getDepartment());
				preparedStatement.setString(6, employee.getDesignation());
				preparedStatement.addBatch();
			}
			preparedStatement.executeBatch();
			connection.commit();
		} catch (Exception e) {
		}
	}

	public void getEmployeeById(String eid) {

		Employee employee = new Employee();
		try {
			preparedStatement = connection.prepareStatement(UtilQ.Q("q4"));
			preparedStatement.setString(1, eid);
			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				setEmployeeDetails(resultSet, employee);
			}
			ArrayList<Employee> l = new ArrayList<Employee>();
			l.add(employee);
			employeeOutput(l);
		} catch (Exception ex) {
		}
	}
	
	public Employee setEmployeeDetails(ResultSet resultSet, Employee employee) {
		try {
			employee.setEmployeeId(resultSet.getString(1));
			employee.setFullName(resultSet.getString(2));
			employee.setAddress(resultSet.getString(3));
			employee.setFacultyName(resultSet.getString(4));
			employee.setDepartment(resultSet.getString(5));
			employee.setDesignation(resultSet.getString(6));
		}catch(SQLException ex) {
			
		}
		return employee;
	}

	public void deleteEmployee(String eid) {

		try {
			preparedStatement = connection.prepareStatement(UtilQ.Q("q6"));
			preparedStatement.setString(1, eid);
			preparedStatement.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void displayEmployee() {

		ArrayList<Employee> l = new ArrayList<Employee>();
		try {
			preparedStatement = connection.prepareStatement(UtilQ.Q("q5"));
			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				Employee employee = new Employee();
				setEmployeeDetails(resultSet, employee);
				l.add(employee);
			}
		} catch (Exception e) {
		}
		employeeOutput(l);
	}
	
	public void employeeOutput(ArrayList<Employee> employeeList){
		
		System.out.println("Employee ID" + "\t\t" + "Full Name" + "\t\t" + "Address" + "\t\t" + "Faculty Name" + "\t\t"
				+ "Department" + "\t\t" + "Designation" + "\n");
		System.out
				.println("================================================================================================================");
		for(int i = 0; i < employeeList.size(); i++){
			Employee employee = employeeList.get(i);
			System.out.println(employee.getEmployeeId() + "\t" + employee.getFullName() + "\t\t"
					+ employee.getAddress() + "\t" + employee.getFacultyName() + "\t" + employee.getDepartment() + "\t"
					+ employee.getDesignation() + "\n");
			System.out
			.println("----------------------------------------------------------------------------------------------------------------");
		}
		
	}
}
